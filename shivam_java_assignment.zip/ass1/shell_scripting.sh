# This is shell scripting which includes java class Content_Reader

#!/bin.sh

# Define variables
created_java_class="Content_Reader"
directory_path="./home/shivam/Documents/java_assignment"
stopwords=("themselves" "where" "had" "been" "and" "is" "the" "in" "of" "it" "a" "to" "this" "with" "those" "for" "on" "at" "an" "by" "as" "that" "which" "not" "are" "you" "we" "can" "be" "from" "or" "with" "have" "has" "was" "your" "his" "its" "their" "her" "them" "they")

# here compilation of  Java program is happening
javac $created_java_class.java

# it will run the java program
java $created_java_class $directory_path "${stopwords[@]}"

# this is removing the class while compilation
rm $created_java_class.class

